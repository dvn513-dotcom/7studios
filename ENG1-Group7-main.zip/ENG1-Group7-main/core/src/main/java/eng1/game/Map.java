package eng1.game;

import com.badlogic.gdx.graphics.glutils.ShapeRenderer;
import java.io.InputStream;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;

public class Map {
    public int w;
    public int h;
    public int[][] tiles;

    public static final float TILE_SIZE = 64.0f;

    public Map(String filename) {
        loadMap(filename);
    }

    public void loadMap(String filename) {
        try (InputStream mapInputStream = getClass().getResourceAsStream(filename);
                BufferedReader mapReader = new BufferedReader(new InputStreamReader(mapInputStream))) {

            // Extract map width/height from first line
            String mapSize = mapReader.readLine();
            String[] sizeSplit = mapSize.split(",");

            this.w = Integer.parseInt(sizeSplit[0]);
            this.h = Integer.parseInt(sizeSplit[1]);

            this.tiles = new int[this.h][this.w];

            // Extract tile data
            for (int i = 0; i < h; i++) {
                String mapRow = mapReader.readLine();
                for (int j = 0; j < w; j++) {
                    this.tiles[i][j] = mapRow.charAt(j) - '0'; // Convert char to decimal value with ASCII magic
                }
            }

            mapReader.close();

        } catch (IOException e) {
            System.err.println("Error loading map file");
        }
    }

    public void draw() {
        ShapeRenderer shape = new ShapeRenderer();
        shape.begin(ShapeRenderer.ShapeType.Filled);

        for (int i = 0; i < this.h; i++) {
            for (int j = 0; j < this.w; j++) {
                switch (this.tiles[i][j]) {
                    case 0: // Empty Tile
                    case 6: // Hidden path
                        break;

                    case 1: // Floor tile
                    case 2: // Player spawn point
                    case 4: // Hidden pressure plate
                        shape.setColor(1, 1, 1, 1);
                        shape.rect(j * TILE_SIZE, (this.h - i - 1) * TILE_SIZE, TILE_SIZE, TILE_SIZE);
                        break;

                    case 3: // Cobweb
                        shape.setColor(1, 0, 0, 1);
                        shape.rect(j * TILE_SIZE, (this.h - i - 1) * TILE_SIZE, TILE_SIZE, TILE_SIZE);
                        break;

                    case 5: // Pressed pressure plate
                        shape.setColor(0, 1, 1, 1);
                        shape.rect(j * TILE_SIZE, (this.h - i - 1) * TILE_SIZE, TILE_SIZE, TILE_SIZE);
                        break;

                    case 7: // Coins
                        shape.setColor(1, 1, 0, 1);
                        shape.rect(j * TILE_SIZE, (this.h - i - 1) * TILE_SIZE, TILE_SIZE, TILE_SIZE);
                        break;

                    case 8: // Speed boost
                        shape.setColor(0, 1, 0, 1);
                        shape.rect(j * TILE_SIZE, (this.h - i - 1) * TILE_SIZE, TILE_SIZE, TILE_SIZE);
                        break;

                    case 9: // Exit
                        shape.setColor(0.7f, 0.35f, 0, 0);
                        shape.rect(j * TILE_SIZE, (this.h - i - 1) * TILE_SIZE, TILE_SIZE, TILE_SIZE);
                        break;
                }
            }
        }

        shape.end();
    }

    public void setTile(int x, int y, int tile) {
        this.tiles[y][x] = tile;
    }

    public int getTile(int x, int y) {
        return this.tiles[y][x];
    }

    public int[] getSize() {
        int[] size = { this.w, this.h };
        return size;
    }

    public int[] getSpawnTile() {
        for (int i = 0; i < this.h; i++) {
            for (int j = 0; j < this.w; j++) {
                if (this.tiles[i][j] == 2) {
                    int[] spawnTile = { j, i };
                    return spawnTile;
                }
            }
        }

        int[] spawnTile = { 0, 0 };
        return spawnTile;
    }

    public static boolean checkWalkable(int tile) {
        if (tile != 0 && tile != 6) {
            return true;
        } else {
            return false;
        }
    }
}
