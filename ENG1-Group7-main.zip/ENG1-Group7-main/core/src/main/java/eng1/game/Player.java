package eng1.game;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input.Keys;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;

public class Player {
    int x;
    int y;
    int facing;
    int size;
    int xSpeed;
    int ySpeed;
    int coins;
    boolean speedBoost;
    boolean foundSpeedBoost;
    int speedTime;
    int currentTime;
    long startTime = System.currentTimeMillis();
    int negativeEvents;
    String hiddenEvents = "Not found";
    boolean winCondition = false;

    public Player(int x, int y, int facing, int size, int xSpeed, int ySpeed) {
        this.x = x;
        this.y = y;
        this.facing = facing;
        this.size = size;
        this.xSpeed = xSpeed;
        this.ySpeed = ySpeed;
        this.coins = 0;
        this.speedBoost = false;
        this.speedTime = 0;
    }

    public void update(long startTime, Map map) {

        int currentXSpeed = xSpeed;
        int currentYSpeed = ySpeed;

        if (speedBoost == true) {
            currentXSpeed *= 1.5;
            currentYSpeed *= 1.5;
        }

        // Check for cobwebs
        if (checkCurrentTile(map, x, y) == 3 || checkCurrentTile(map, x, y + 50) == 3) {
            currentXSpeed /= 2;
            currentYSpeed /= 2;
            negativeEvents = 1;
        }

        // Check for pressure plates
        if (checkCurrentTile(map, x, y) == 4 || checkCurrentTile(map, x, y + 50) == 4) {
            // If we step on the pressure plate, find all plates and activate them, and turn
            // all hidden paths into walkable floor tiles
            for (int i = 0; i < map.h; i++) {
                for (int j = 0; j < map.w; j++) {
                    if (map.getTile(j, i) == 4) {
                        map.setTile(j, i, 5);
                    }

                    if (map.getTile(j, i) == 6) {
                        map.setTile(j, i, 1);
                    }
                }
            }
            hiddenEvents = "Found";
        }

        // Check for coin
        if (checkCurrentTile(map, x, y) == 7 && checkCurrentTile(map, x, y + 50) == 7) {
            int tileX = (int) (x / Map.TILE_SIZE);
            int tileY = map.h - (int) (y / Map.TILE_SIZE) - 1;

            map.setTile(tileX, tileY, 1);
            coins += 1;
        }

        // Check for speed boost
        if (checkCurrentTile(map, x, y) == 8 && checkCurrentTile(map, x, y + 50) == 8) {
            speedBoost = true;
            foundSpeedBoost = true;
            long elapsedTime = System.currentTimeMillis() - startTime;

            speedTime = (int) elapsedTime / 1000;
        }

        // Check for maze exit
        if (checkCurrentTile(map, x, y) == 9 && coins >= 10) {
            winCondition = true;
        }

        // Handle input
        if (Gdx.input.isKeyPressed(Keys.D) && Map.checkWalkable(checkCurrentTile(map, x + currentXSpeed + 40, y))) {
            x += currentXSpeed;
        }

        if (Gdx.input.isKeyPressed(Keys.A) && Map.checkWalkable(checkCurrentTile(map, x - currentXSpeed, y))) {
            x -= currentXSpeed;
        }

        if (Gdx.input.isKeyPressed(Keys.W) && Map.checkWalkable(checkCurrentTile(map, x, y + currentYSpeed + 45))) {
            y += currentYSpeed;
        }

        if (Gdx.input.isKeyPressed(Keys.S) && Map.checkWalkable(checkCurrentTile(map, x, y - currentYSpeed))) {
            y -= currentYSpeed;
        }

    }

    public int checkCurrentTile(Map map, int x, int y) {
        int tileX = (int) (x / Map.TILE_SIZE);
        int tileY = map.h - (int) (y / Map.TILE_SIZE) - 1;

        int tile = map.getTile(tileX, tileY);

        return tile;
    }

    public void draw(SpriteBatch spriteBatch, Texture playerTexture) {
        spriteBatch.draw(playerTexture, x, y, 40, 40);
    }

    public int getCoins() {
        return coins;
    }

    public void setCoins(int coins) {
        this.coins = coins;
    }

    public boolean getSpeedBoost() {
        return speedBoost;
    }

    public int getSpeedTime() {
        return speedTime;
    }

    public void setSpeedTime(int time) {
        speedTime = time;
    }

    public void checkSpeedBoost(long startTime) {
        long elapsedTime = (System.currentTimeMillis() - startTime) / 1000;

        if (elapsedTime >= (speedTime + 10)) {
            speedBoost = false;
        }
    }

    public int getNegativeEvents() {
        return negativeEvents;
    }

    public String getHiddenEvents() {
        return hiddenEvents;
    }

    public void setPlayerX(int map_x) {
        x = map_x;
    }

    public void setPlayerY(int map_y) {
        y = map_y;
    }
}
