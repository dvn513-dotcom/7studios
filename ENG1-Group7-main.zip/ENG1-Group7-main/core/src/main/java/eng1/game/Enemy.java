package eng1.game;

public class Enemy extends Player {
    public Enemy(int x, int y, int facing, int size, int xSpeed, int ySpeed) {
        super(x, y, facing, size, xSpeed, ySpeed);
    }

    @Override
    public void update(long startTime, Map map) {
        // Check if there is a wall in front of us, if so change directions.
        switch (facing) {
            case 0: // Right
                if (!Map.checkWalkable(checkCurrentTile(map, x + xSpeed + 40, y))) { // Check if we cant move right.
                    if (Map.checkWalkable(checkCurrentTile(map, x, y + ySpeed + 45))) { // Check if we can move up.
                        facing = 1;
                    } else if (Map.checkWalkable(checkCurrentTile(map, x - xSpeed, y))) { // Check if we can move left.
                        facing = 2;
                    } else { // If we can't move anywhere else, move down.
                        facing = 3;
                    }
                }
                break;

            case 1: // Up
                if (!Map.checkWalkable(checkCurrentTile(map, x, y + ySpeed + 45))) { // Check if we cant move up.
                    if (Map.checkWalkable(checkCurrentTile(map, x + xSpeed + 40, y))) { // Check if we can move right.
                        facing = 0;
                    } else if (Map.checkWalkable(checkCurrentTile(map, x - xSpeed, y))) { // Check if we can move left.
                        facing = 2;
                    } else { // If we can't move anywhere else, move down.
                        facing = 3;
                    }
                }
                break;

            case 2: // Left
                if (!Map.checkWalkable(checkCurrentTile(map, x - xSpeed, y))) { // Check if we cant move left.
                    if (Map.checkWalkable(checkCurrentTile(map, x, y + ySpeed + 45))) { // Check if we can move up.
                        facing = 1;
                    } else if (Map.checkWalkable(checkCurrentTile(map, x, y - ySpeed))) { // Check if we can move down.
                        facing = 3;
                    } else { // If we can't move anywhere else, move right.
                        facing = 0;
                    }
                }
                break;

            case 3: // Down
                if (!Map.checkWalkable(checkCurrentTile(map, x, y - ySpeed))) { // Check if we cant move down.
                    if (Map.checkWalkable(checkCurrentTile(map, x - xSpeed, y))) { // Check if we can move left.
                        facing = 2;
                    } else if (Map.checkWalkable(checkCurrentTile(map, x + xSpeed + 40, y))) { // Check if we can move
                                                                                               // right.
                        facing = 0;
                    } else { // If we can't move anywhere else, move up.
                        facing = 1;
                    }
                }
                break;
        }

        // Move forward in whatever direction we are facing.
        switch (facing) {
            case 0: // Right
                x += xSpeed;
                break;

            case 1: // Up
                y += ySpeed;
                break;

            case 2: // Left
                x -= xSpeed;
                break;

            case 3: // Down
                y -= ySpeed;
                break;
        }
    }
}
