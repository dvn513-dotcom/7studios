package eng1.game;

import com.badlogic.gdx.ApplicationAdapter;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Graphics;
import com.badlogic.gdx.graphics.glutils.ShapeRenderer;
import com.badlogic.gdx.graphics.GL20;

/**
 * {@link com.badlogic.gdx.ApplicationListener} implementation shared by all
 * platforms.
 */

public class Main extends ApplicationAdapter {
    private ShapeRenderer shape;
    private Player player;
    private Enemy enemy;
    private Texture playerTexture;
    private Texture enemyTexture;
    private Texture controlTexture;
    private SpriteBatch spriteBatch;
    private BitmapFont font;
    private int positiveEvents;
    private int currentTime;
    private long startTime = System.currentTimeMillis();
    private int maxTime = 301;
    private String timeRemaining;
    private Map map;

    @Override
    public void create() {
        playerTexture = new Texture("Standing.png");
        enemyTexture = new Texture("Enemy.png");
        controlTexture = new Texture("Tutorial.png");
        spriteBatch = new SpriteBatch();
        shape = new ShapeRenderer();
        player = new Player(150, 200, 10, 45, 2, 2);
        enemy = new Enemy(150, 200, 0, 45, 2, 2);
        font = new BitmapFont();
        map = new Map("/map.txt");

        font.getData().setScale(2.0f);

        int[] spawnTile = map.getSpawnTile();

        // Move enemy and player to spawn position
        int x = (spawnTile[0]) * (int) Map.TILE_SIZE;
        player.setPlayerX(x);
        enemy.setPlayerX(x);
        int y = (map.h - spawnTile[1]) * (int) Map.TILE_SIZE;
        player.setPlayerY(y);
        enemy.setPlayerY(y);

        // Default to opening in fullscreen
        Graphics.DisplayMode currentMode = Gdx.graphics.getDisplayMode();
        Gdx.graphics.setFullscreenMode(currentMode);
    }

    @Override
    public void render() {
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);
        shape.begin(ShapeRenderer.ShapeType.Filled);

        map.draw();
        shape.end();

        spriteBatch.begin();

        currentTime = (int) checkTime(startTime);
        currentTime = maxTime - currentTime; // is overwriting the additional time, add a + cointotal

        spriteBatch.draw(controlTexture, 1740, 900, 150, 150);
        timeRemaining = "Time Remaining: " + currentTime;

        double playerEnemyXDistance = Math.abs(player.x - enemy.x);
        double playerEnemyYDistance = Math.abs(player.y - enemy.y);
        double playerEnemyDistance = Math
                .sqrt(playerEnemyXDistance * playerEnemyXDistance + playerEnemyYDistance * playerEnemyYDistance);

        if (currentTime <= 0 || player.winCondition == true) {
            endScreen();
        } else {
            // Respawn player if they touch the enemy (and apply a time penalty)
            if (playerEnemyDistance < 30 && maxTime - currentTime > 5) {
                maxTime -= 10;
                int[] spawnTile = map.getSpawnTile();
                player.x = (spawnTile[0]) * (int) Map.TILE_SIZE;
                ;
                player.y = (map.h - spawnTile[1]) * (int) Map.TILE_SIZE;
            }

            if (maxTime - currentTime > 5) {
                enemy.update(startTime, map);
                enemy.draw(spriteBatch, enemyTexture);
            }

            player.update(startTime, map);
            player.draw(spriteBatch, playerTexture);
        }

        // Draw HUD
        font.draw(spriteBatch, timeRemaining, 0, 1050);
        font.draw(spriteBatch, "Coins: " + player.getCoins(), 0, 900);
        player.checkSpeedBoost(startTime);
        font.draw(spriteBatch, "Speed Boost: " + player.getSpeedBoost(), 300, 1050);
        font.draw(spriteBatch, "Positive: " + (positiveEvents + (player.foundSpeedBoost ? 1 : 0)), 570, 1050);
        font.draw(spriteBatch, "Negative: " + player.getNegativeEvents(), 730, 1050);
        font.draw(spriteBatch, "Hidden Event: " + player.getHiddenEvents(), 900, 1050);

        spriteBatch.end();
    }

    public long checkTime(long startTime) {
        long elapsedTime = System.currentTimeMillis() - startTime;
        long elapsedSeconds = elapsedTime / 1000;

        return elapsedSeconds;
    }

    public void endScreen() {
        Gdx.graphics.setContinuousRendering(false);
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);
        font.draw(spriteBatch, "GAME OVER", 870, 540);
        font.draw(spriteBatch, "Score:" + ((currentTime * player.getCoins())), 870, 700);
    }

}